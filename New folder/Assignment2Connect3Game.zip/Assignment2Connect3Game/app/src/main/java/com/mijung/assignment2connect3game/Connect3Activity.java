package com.mijung.assignment2connect3game;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.mijung.assignment2connect3game.databinding.ActivityConnect3Binding;
import java.util.ArrayList;
import java.util.List;

public class Connect3Activity extends AppCompatActivity {

    ActivityConnect3Binding binding;
    private final List<int[]> combinationList = new ArrayList<>();
    private int[] boxPositions = {0, 0, 0, 0, 0, 0, 0, 0, 0}; // 9 zero
    private int playerTurn = 1;
    private String userName1, userName2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityConnect3Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Get usernames from intent
        Intent intent = getIntent();
        userName1 = intent.getStringExtra("USERNAME1");
        userName2 = intent.getStringExtra("USERNAME2");

        initializeCombinationList();
        initializeClickListeners();
    }

    private void initializeCombinationList() {
        combinationList.add(new int[]{0, 1, 2});
        combinationList.add(new int[]{3, 4, 5});
        combinationList.add(new int[]{6, 7, 8});
        combinationList.add(new int[]{0, 3, 6});
        combinationList.add(new int[]{1, 4, 7});
        combinationList.add(new int[]{2, 5, 8});
        combinationList.add(new int[]{2, 4, 6});
        combinationList.add(new int[]{0, 4, 8});
    }

    private void initializeClickListeners() {
        binding.image1.setOnClickListener(view -> onBoxClicked(0));
        binding.image2.setOnClickListener(view -> onBoxClicked(1));
        binding.image3.setOnClickListener(view -> onBoxClicked(2));
        binding.image4.setOnClickListener(view -> onBoxClicked(3));
        binding.image5.setOnClickListener(view -> onBoxClicked(4));
        binding.image6.setOnClickListener(view -> onBoxClicked(5));
        binding.image7.setOnClickListener(view -> onBoxClicked(6));
        binding.image8.setOnClickListener(view -> onBoxClicked(7));
        binding.image9.setOnClickListener(view -> onBoxClicked(8));

        binding.playagainBtn.setOnClickListener(view -> restartMatch());
        binding.quitgameBtn.setOnClickListener(view -> quitGame());
    }

    private void onBoxClicked(int boxPosition) {
        if (isBoxSelectable(boxPosition)) {
            performAction(boxPosition);
            if (checkResults()) {
                showCongratulatoryMessage();
            } else {
                playerTurn = (playerTurn == 1) ? 2 : 1;
            }
        } else {
            Toast.makeText(this, "This box is already selected!", Toast.LENGTH_SHORT).show();
        }
    }

    private void showCongratulatoryMessage() {
        String winnerName = (playerTurn == 1) ? userName1 : userName2;
        binding.resultText.setText("Congrats " + winnerName + "!");
    }

    private boolean checkResults() {
        boolean allBoxesFilled = true;

        // Check if all boxes are filled
        for (int position : boxPositions) {
            if (position == 0) {
                allBoxesFilled = false;
                break;
            }
        }

        // Check for winning combinations
        for (int[] combination : combinationList) {
            if (boxPositions[combination[0]] == playerTurn && boxPositions[combination[1]] == playerTurn &&
                    boxPositions[combination[2]] == playerTurn) {
                return true;
            }
        }

        // If all boxes are filled but no winner, it's a draw
        if (allBoxesFilled) {
            showDrawMessage();
        }

        return false;
    }

    private void showDrawMessage() {
        binding.resultText.setText("It's a draw!");
    }

    private boolean isBoxSelectable(int boxPosition) {
        return boxPositions[boxPosition] == 0;
    }

    private void performAction(int boxPosition) {
        ImageView imageView = getImageViewByPosition(boxPosition);
        if (playerTurn == 1) {
            imageView.setImageResource(R.drawable.cross);
        } else {
            imageView.setImageResource(R.drawable.circle);
        }
        boxPositions[boxPosition] = playerTurn;
    }

    private ImageView getImageViewByPosition(int position) {
        switch (position) {
            case 0:
                return binding.image1;
            case 1:
                return binding.image2;
            case 2:
                return binding.image3;
            case 3:
                return binding.image4;
            case 4:
                return binding.image5;
            case 5:
                return binding.image6;
            case 6:
                return binding.image7;
            case 7:
                return binding.image8;
            case 8:
                return binding.image9;
            default:
                return null;
        }
    }

    private void restartMatch() {
        boxPositions = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0}; // 9 zero
        playerTurn = 1;
        binding.resultText.setText("");
        binding.image1.setImageResource(R.drawable.empty);
        binding.image2.setImageResource(R.drawable.empty);
        binding.image3.setImageResource(R.drawable.empty);
        binding.image4.setImageResource(R.drawable.empty);
        binding.image5.setImageResource(R.drawable.empty);
        binding.image6.setImageResource(R.drawable.empty);
        binding.image7.setImageResource(R.drawable.empty);
        binding.image8.setImageResource(R.drawable.empty);
        binding.image9.setImageResource(R.drawable.empty);
    }

    private void quitGame() {
        Intent intent = new Intent(this, WelcomeActivity.class);
        startActivity(intent);
        finish();
    }
}