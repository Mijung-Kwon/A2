package com.mijung.assignment2connect3game;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Start the SplashActivity when the main activity is created
        Intent intent = new Intent(MainActivity.this, SplashActivity.class);
        startActivity(intent);
        finish(); // Finish the MainActivity so that it won't be shown when pressing back button
    }
}